#!/usr/bin/env python3
"""Genuine matched external views; no performance claim for capture runs."""
import argparse,hashlib,json,os,pathlib,subprocess,sys
ROOT=pathlib.Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'tools'))
from light_tour import parse_tour
from surface_streaming.measure import sha
ap=argparse.ArgumentParser();ap.add_argument('--exe',type=pathlib.Path,required=True);ap.add_argument('--out',type=pathlib.Path,required=True)
ap.add_argument('--cases',default='ruts,plough');a=ap.parse_args();a.exe=a.exe.resolve();a.out=a.out.resolve()
for case in a.cases.split(','):
 tour=ROOT/'tools/surface_streaming'/('plough-tour.txt' if case=='plough' else 'ruts-close-tour.txt' if case=='ruts_close' else 'tracks-tour.txt')
 steps,end=parse_tour(tour);target=a.out/case
 if target.exists():raise SystemExit('Use a new evidence folder: '+str(target))
 target.mkdir(parents=True)
 cmd=[str(a.exe),'--headless','--rhi','metal','--res','1280x720','--scene','play_region','--sandbox','--seed','2' if case=='plough' else '1','--timescale','0','--gi','off','--shadows','low','--clouds','low','--data-dir',str(ROOT/'build/map/r1'),'--out',str(target),'--light-tour',str(tour),'--capture',','.join(str(s[2]) for s in steps),'--ticks',str(end+1)]
 if case=='plough':cmd+=['--start','winterplow_down','--season','winter:0.3','--replay',str(ROOT/'tools/replays/net_n0_winterplow.txt')]
 else:cmd+=['--start','ruts_drive','--season','summer:0.5','--replay',str(ROOT/'tools/replays/rut1_drive.txt')]
 env=os.environ.copy();env.update(PEREGON_PROFILE_DIR=str(target/'profile'),PEREGON_RHI_VALIDATE='1',PEREGON_FAUNA='inline',PEREGON_SURFACE_AUDIT='1')
 for k in ('PEREGON_INPUT_SCRIPT','PEREGON_INPUT_TIMED'):env.pop(k,None)
 meta=dict(command=cmd,exe_sha256=sha(a.exe),dylibs={p.name:sha(p) for p in a.exe.parent.glob('*.dylib')},captures=steps)
 (target/'run.json').write_text(json.dumps(meta,indent=2));print(case,flush=True)
 with (target/'stdout.log').open('w') as out,(target/'stderr.log').open('w') as err:r=subprocess.run(cmd,cwd=ROOT,env=env,stdout=out,stderr=err)
 if r.returncode:raise SystemExit(r.returncode)
