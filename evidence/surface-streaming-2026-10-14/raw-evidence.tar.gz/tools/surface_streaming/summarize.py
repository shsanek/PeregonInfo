#!/usr/bin/env python3
"""Summarize matched surface runs without treating capture/startup frames as steady-state samples."""
import argparse, csv, json, pathlib, re, statistics
CASES = ('summer', 'ruts', 'winter', 'blizzard')
def load(path):
    return json.loads(path.read_text())
def median(values):
    return statistics.median(values)
def group(root, case):
    runs=[]
    for path in sorted((root/case).glob('run*/summary.json')):
        s=load(path);m=load(path.parent/'metrics.json');scene=m['scene_metrics'];p=scene['play']
        assert s['returncode']==0 and m['rhi']['errors']==0
        # The profiler writes the previous completed interval; shutdown can
        # leave the last of 1800 simulated frames pending (1799 CSV rows).
        assert m['ticks']==1800 and s['frames'] in (1799,1800), (path,m['ticks'],s['frames'])
        assert p['drive_m']>20,(path,p['drive_m'])
        if case in ('winter','blizzard'):assert p['snowpack_mm']>=300
        if case=='blizzard':assert p['snowpack_mm']>315 # --timescale 0 is uncapped simulation, not paused weather.
        if case=='ruts':assert p['shovel']['ruts']['writes']>10000
        stderr=(path.parent/'stderr.log').read_text()
        gpu=re.search(r'metal gpu time: .*?, ([0-9.]+) ms per frame',stderr)
        peak=re.search(r'metal allocation peak: ([0-9]+) bytes',stderr)
        fields=scene.get('surface_streaming',{})
        if fields:
            # a666a4bdda end-of-run audit integrated the stored rut convention
            # (positive depression). Convert to physical signed height here;
            # keep original metrics.json untouched and state the correction.
            rut=fields['ruts']
            if 'audit_height_sign' not in rut:
                rut['audit_cut_m3'],rut['audit_pile_m3']=rut['audit_pile_m3'],rut['audit_cut_m3']
                rut['audit_min_m'],rut['audit_max_m']=-rut['audit_max_m'],-rut['audit_min_m']
                rut['audit_normalized_from']='stored-positive-rut-depth; original raw JSON unchanged'
            if case=='ruts':assert fields['ruts']['audit_cut_m3']>.1
            if case in ('winter','blizzard'):assert fields['snow']['audit_cut_m3']>.1
            if case=='blizzard':assert fields['snow']['snowfall_m']>0
            assert all(fields[k]['io_errors']==0 for k in ('ruts','snow','drifts'))
        runs.append(dict(path=str(path.parent),cpu_ms=s['cpu_ms'],rss_mib=s['peak_rss_kib']/1024,
                         gpu_ms=float(gpu[1]) if gpu else None,metal_allocation_bytes=int(peak[1]) if peak else None,
                         drive_m=p['drive_m'],snowpack_mm=p['snowpack_mm'],surface=fields,
                         surface_geometry_gpu_bytes=scene.get('snow_mesh',{}).get('surface_geometry_gpu_bytes'),
                         cold_start_frame_avg_ms=m['frame_time_ms']['avg'],frame_max_including_startup_ms=m['frame_time_ms']['max'],
                         rut_legacy_diagnostics=p['shovel']['ruts'],snow_mesh=scene.get('snow_mesh')))
    assert len(runs)==3,(root,case,len(runs))
    out={name:median([r['cpu_ms']['total'][name] for r in runs]) for name in ('mean','median','p95','p99','max')}
    out['fps_from_mean']=1000/out['mean'];out['rss_mib']=median([r['rss_mib'] for r in runs])
    out['gpu_ms']=median([r['gpu_ms'] for r in runs]) if all(r['gpu_ms'] is not None for r in runs) else None
    out['metal_allocation_bytes']=max([r['metal_allocation_bytes'] or 0 for r in runs]) or None
    out['runs']=runs
    return out

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--before',type=pathlib.Path,required=True)
    ap.add_argument('--after',type=pathlib.Path,required=True);ap.add_argument('--out',type=pathlib.Path,required=True);a=ap.parse_args()
    before=load(a.before/'manifest.json');after=load(a.after/'manifest.json')
    assert before['map_sha256']==after['map_sha256']
    assert before['platform']==after['platform']
    result=dict(method='Three 1800-tick runs per case, first 300 frames excluded; median of per-run distributions. RSS includes startup. GPU timing includes all frames. Captures are separate.',before_manifest=before,after_manifest=after,cases={})
    for case in CASES:
        b=group(a.before,case);c=group(a.after,case)
        result['cases'][case]=dict(before=b,after=c,median_delta_ms=c['median']-b['median'],median_delta_pct=100*(c['median']/b['median']-1),rss_delta_mib=c['rss_mib']-b['rss_mib'])
    a.out.parent.mkdir(parents=True,exist_ok=True);a.out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    with a.out.with_suffix('.csv').open('w') as f:
        w=csv.writer(f);w.writerow(['case','before_median_ms','after_median_ms','delta_pct','before_p95_ms','after_p95_ms','before_p99_ms','after_p99_ms','before_rss_mib','after_rss_mib','before_gpu_ms','after_gpu_ms'])
        for name,c in result['cases'].items():
            b,n=c['before'],c['after'];w.writerow([name,b['median'],n['median'],c['median_delta_pct'],b['p95'],n['p95'],b['p99'],n['p99'],b['rss_mib'],n['rss_mib'],b['gpu_ms'],n['gpu_ms']])
    print(a.out)
if __name__=='__main__':main()
