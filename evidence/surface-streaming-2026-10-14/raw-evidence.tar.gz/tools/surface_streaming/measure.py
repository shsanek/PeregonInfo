#!/usr/bin/env python3
"""Matched sandbox surface cases; retains commands, hashes, raw timings and RSS.
Captures use a separate run so framebuffer readback does not bias timings.
"""
import argparse, csv, hashlib, json, os, pathlib, statistics, subprocess, time
ROOT = pathlib.Path(__file__).resolve().parents[2]
CASES = {
    'summer': ['--render-perf-route', 'summer-road', '--weather', 'clear'],
    'ruts': ['--start', 'ruts_drive', '--replay', str(ROOT/'tools/replays/rut1_drive.txt'), '--season', 'summer:0.5', '--weather', 'rain'],
    'winter': ['--render-perf-route', 'winter-road-clear', '--weather', 'clear'],
    'blizzard': ['--render-perf-route', 'winter-road-blizzard', '--weather', 'snow'],
}
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''): h.update(b)
    return h.hexdigest()
def dist(v):
    v=sorted(v)
    return dict(n=len(v),mean=statistics.mean(v),median=statistics.median(v),p95=v[int((len(v)-1)*.95)],p99=v[int((len(v)-1)*.99)],max=max(v)) if v else {}
def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--exe',type=pathlib.Path,required=True);ap.add_argument('--out',type=pathlib.Path,required=True)
    ap.add_argument('--data',type=pathlib.Path,default=ROOT/'build/map/r1');ap.add_argument('--repetitions',type=int,default=3)
    ap.add_argument('--ticks',type=int,default=1800);ap.add_argument('--cases',default=','.join(CASES));ap.add_argument('--captures-only',action='store_true')
    ap.add_argument('--repetition-id',type=int,help='Run one timed repetition, for strictly interleaved version pairs')
    a=ap.parse_args();
    if a.repetition_id is not None and (a.captures_only or not 0<=a.repetition_id<a.repetitions):ap.error('repetition-id must select a timed repetition')
    a.exe=a.exe.resolve();a.out=a.out.resolve();a.data=a.data.resolve();a.out.mkdir(parents=True,exist_ok=True)
    manifest=dict(dylibs={p.name:sha(p) for p in a.exe.parent.glob('*.dylib')},exe_sha256=sha(a.exe),map_sha256=sha(a.data/'peregon_map.pak'),git=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),ticks=a.ticks,platform=subprocess.check_output(['uname','-a'],text=True).strip())
    if (a.out/'manifest.json').exists():
        old=json.loads((a.out/'manifest.json').read_text())
        if old.get('exe_sha256')!=manifest['exe_sha256'] or old.get('dylibs')!=manifest['dylibs']:
            raise SystemExit('Refusing to mix different binaries: use a new evidence directory')
    (a.out/'manifest.json').write_text(json.dumps(manifest,indent=2))
    for case in a.cases.split(','):
        selected=[a.repetition_id] if a.repetition_id is not None else ([a.repetitions] if a.captures_only else range(a.repetitions+1))
        for rep in selected:
            capture=rep==a.repetitions
            if a.captures_only and not capture: continue
            target=a.out/case/('captures' if capture else 'run%d'%rep)
            if (target/'summary.json').exists(): continue
            target.mkdir(parents=True,exist_ok=True)
            cmd=[str(a.exe),'--headless','--rhi','metal','--res','1280x720','--scene','play_region','--sandbox','--seed','1','--timescale','0','--time','13:20','--gi','off','--shadows','low','--clouds','low','--data-dir',str(a.data),'--out',str(target)]+CASES[case]+['--ticks',str(a.ticks)]
            if capture: cmd+=['--capture',','.join(str(t) for t in (300,900,a.ticks) if t<=a.ticks)]
            env=os.environ.copy();env.update(PEREGON_PROFILE_DIR=str(target/'profile'),PEREGON_RHI_VALIDATE='0',PEREGON_FAUNA='inline',PEREGON_SURFACE_AUDIT='1')
            for k in ('PEREGON_INPUT_SCRIPT','PEREGON_INPUT_TIMED'):env.pop(k,None)
            meta=dict(exe_sha256=manifest['exe_sha256'],dylibs=manifest['dylibs'],command=cmd,started=time.strftime('%Y-%m-%dT%H:%M:%S%z'),capture=capture,environment={k:v for k,v in env.items() if k.startswith('PEREGON_')})
            (target/'run.json').write_text(json.dumps(meta,indent=2))
            print(case,target.name,flush=True);start=time.perf_counter();rss=[]
            with (target/'stdout.log').open('w') as stdout,(target/'stderr.log').open('w') as stderr,(target/'resources.csv').open('w') as rf:
                rf.write('seconds,rss_kib,cpu_percent\n')
                p=subprocess.Popen(cmd,cwd=ROOT,env=env,stdout=stdout,stderr=stderr)
                while p.poll() is None:
                    s=subprocess.run(['ps','-o','rss=,pcpu=','-p',str(p.pid)],capture_output=True,text=True).stdout.split()
                    if len(s)==2: rss.append(int(s[0]));rf.write(f'{time.perf_counter()-start:.3f},{s[0]},{s[1]}\n');rf.flush()
                    try:p.wait(timeout=1)
                    except subprocess.TimeoutExpired:pass
            meta.update(returncode=p.returncode,wall_s=time.perf_counter()-start,peak_rss_kib=max(rss,default=0))
            (target/'run.json').write_text(json.dumps(meta,indent=2))
            if p.returncode: raise SystemExit(f'Failed {target}: {p.returncode}')
            with (target/'perf_frames.csv').open() as f: rows=list(csv.DictReader(f))
            measured=rows[300:]
            out=dict(**meta,frames=len(rows),cpu_ms={k:dist([float(r[k])/1000 for r in measured]) for k in ('total','tick','tick_physics','detail','map','nature_update')})
            out['fps_from_mean_frame']=1000/out['cpu_ms']['total']['mean']
            (target/'summary.json').write_text(json.dumps(out,indent=2))
    return 0
if __name__=='__main__':raise SystemExit(main())
